# Python -> UDP packets -> this script -> Overlay UI

# Creates the UDP listener
extends Node

var udp := PacketPeerUDP.new()

# Connects to UI
@onready var overlay = $"../OverlayLayer (CanvasLayer)/DetectionOverlay (Control)"

# Starts listener: send me anything that arrives at port 4242
func _ready():

	udp.bind(4242)

	print("Listening for AI detections")

# Checks if anything arrives
func _process(_delta):
	
	# Keep reading packets while the queue is empty
	while udp.get_available_packet_count() > 0:
		
		# Takes raw bytes, converts to string, and then parses JSON into directory
		var packet = udp.get_packet()
		var text = packet.get_string_from_utf8()
		var data = JSON.parse_string(text)

		# Ignores field if it's not a valid JSON directory
		if typeof(data) != TYPE_DICTIONARY:
			return

		# Identifies bouding box packets (x, y, w, h), then draws box once detected
		if data.has("x") and data.has("y") and data.has("w") and data.has("h"):
			overlay.update_detections([data])

		# Updates UI configs from FLUTTER - layout, colors, text
		elif data.has("hud_fields") or data.has("hud_color"):
			overlay.update_hud_config(data)

		# Prints out non-detection, non-config for debug
		else:
			print("Unknown packet:", data)
